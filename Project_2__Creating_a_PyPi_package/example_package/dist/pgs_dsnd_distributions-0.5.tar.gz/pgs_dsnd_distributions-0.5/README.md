# Overview

This package creates a class Distribution, and two child classes Guassian and Binomial, with several methods for each.

# Usage

To use this package inside a python environment:

```
from pgs_dsnd_distributions import Gaussian, Binomial
```

For help on using each class:

```
help(Gaussian)
help(Binomial)
# Type 'q' to exit help.
```

# Context

This package was uploaded as an exercise in packaging python classes and uploading to PyPi